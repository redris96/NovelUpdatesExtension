# NovelUpdateChromeExtension
A chrome extension for the site https://www.novelupdates.com/
